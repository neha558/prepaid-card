<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

    class DbOperations{
        private $con;

        function __construct(){
            require_once dirname(__FILE__) . '/DbConnect.php';
            $db = new DbConnect; 
            $this->con = $db->connect(); 
        }


        private function isHSFExist($hsfID){
            $stmt = $this->con->prepare("SELECT HSFID FROM ccapp WHERE HSFID = ?");
            $stmt->bind_param("s", $hsfID);
            $stmt->execute(); 
            $stmt->store_result(); 
            return $stmt->num_rows > 0;
        }

        public function selectMSA($req){
            $stmt = $this->con->prepare("SELECT staff_id, fullname, template FROM es_staff WHERE date_updated > ?");
            $stmt->bind_param("s", $req);
            $stmt->execute();
            $stmt->bind_result($staff_id, $fullname, $template);
            $msas = array();
            date_default_timezone_set('Africa/Lagos');
            while($stmt->fetch()){
                $msa = array();
                $msa['staff_id'] = $staff_id;
                $msa['fullname'] = $fullname;
                $msa['template'] = $template;
                $msa['sync_time'] = date('Y-m-d H:i:s');
                array_push($msas,$msa);
            }
            return $msas;
        }
        

        public function insertHSF($reqBody){
            //reading frm JSN
            $hsf_id = $reqBody->HSFID;
            //$unique_field_id = $reqBody->{'Unique_Field_ID'};
            $field_id = $reqBody->{'FieldID'};
            $bags_marketed = $reqBody->{'BagsMarketed'};
            $kg_marketed = $reqBody->{'KGMarketed'};
            $bags_rate = $reqBody->{'BagsRate'};
            $seed_type = $reqBody->{'SeedType'};
            $date_processed = $reqBody->{'DateProcessed'};
            $mold_count = $reqBody->{'MoldCount'};
            $percent_clean = $reqBody->{'PercentClean'};
            $percent_moisture = $reqBody->{'PercentMoisture'};
            $ccoid = $reqBody->{'CCOID'};
            $warehouse = $reqBody->{'WarehouseID'};
            $transporter = $reqBody->{'TransporterID'};
            $update_flag = $reqBody->{'UpdateFlag'};
            $delete_flag = $reqBody->{'DeleteFlag'};
            

            if(!$this->isHSFExist($hsf_id)){

                $stmt = $this->con->
                prepare("REPLACE INTO `ccapp`(`HSFID`, `FieldID`, `BagsMarketed`, `KGMarketed`, `BagsRate`,
                 `SeedType`, `DateProcessed`, `MoldCount`, `PercentClean`, `PercentMoisture`, `CCOID`, `WarehouseID`,
                  `TransporterID`, `UpdateFlag`, `DeleteFlag`) VALUES 
                (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");    

                $stmt->bind_param("sssssssssssssss", $hsf_id, $field_id, $bags_marketed, $kg_marketed, $bags_rate,
                 $seed_type, $date_processed, $mold_count, $percent_clean, $percent_moisture,
                $ccoid, $warehouse, $transporter, $update_flag, $delete_flag);
                if($stmt->execute()){
                    return HSF_CREATED;
                } else{
                    return HSF_FAILURE;
                }
            } else {
                return HSF_EXISTS;
            }

        }

        public function insertTransport($reqBody){
            //reading from JSON
            $hsf_id = $reqBody->HSFID;
            $field_id = $reqBody->{'FieldID'};
            $bags_marketed = $reqBody->{'BagsMarketed'};
            $bags_rate = $reqBody->{'BagsRate'};
            $transporter = $reqBody->{'TransporterID'};
            $ccoid = $reqBody->{'CCOID'};
            $msaid = $reqBody->{'MSAID'};
            $amount_paid = $reqBody->{'AmountPaid'};
            $date_paid = $reqBody->{'DatePaid'};

            if(!$this->isTransportExist($hsf_id)){
                $stmt = $this->con->prepare("INSERT INTO `harvest_transport_payment`(`HSFID`, `FieldID`,
                 `BagsMarketed`, `BagsRate`, `TransporterID`, `CCOID`, `MSAID`, `AmountPaid`,
                  `DatePaid`) VALUES (?,?,?,?,?,?,?,?,?)");
                
                $stmt->bind_param("sssssssss", $hsf_id, $field_id, $bags_marketed, $bags_rate, $transporter,
                $ccoid, $msaid, $amount_paid, $date_paid);

                if($stmt->execute()){
                    return TRANSPORT_CREATED;
                }else{
                    return TRANSPORT_FAILURE;
                }

            } else{
                return TRANSPORT_EXIST;
            }


        }

        private function isTransportExist($hsfID){
            $stmt = $this->con->prepare("SELECT HSFID FROM harvest_transport_payment WHERE HSFID = ?");
            $stmt->bind_param("s", $hsfID);
            $stmt->execute(); 
            $stmt->store_result(); 
            return $stmt->num_rows > 0;
        }
        
        



        



    }