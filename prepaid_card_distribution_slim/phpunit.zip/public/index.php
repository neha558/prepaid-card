<?php
if (PHP_SAPI == 'cli-server') {
    // To help the built-in PHP dev server, check if the request was actually for
    // something which should probably be served as a static file
    $url  = parse_url($_SERVER['REQUEST_URI']);
    $file = __DIR__ . $url['path'];
    if (is_file($file)) {
        return false;
    }
}

require __DIR__ . '/../vendor/autoload.php';
require '../includes/DbOperations.php';

session_start();

// Instantiate the app
$settings = require __DIR__ . '/../src/settings.php';
$app = new \Slim\App($settings);

// Set up dependencies
$dependencies = require __DIR__ . '/../src/dependencies.php';
$dependencies($app);

// Register middleware
$middleware = require __DIR__ . '/../src/middleware.php';
$middleware($app);

// Register routes
$routes = require __DIR__ . '/../src/routes.php';
$routes($app);

// Run app
$app->run();

function insertHSF($request){
	$request_body = $request->getParsedBody();
	$req = json_decode($request_body['jsent']);
	
	$db = new DbOperations;
	$a = array();

	for ($i = 0; $i < count($req); $i++){
		$reqW = $req[$i];
		//print_r($reqW->{'HSFID'});
        //print_r($reqW);
        
		$result = $db->insertHSF($reqW);
    
        date_default_timezone_set('Africa/Lagos');
		//$result = HSF_CREATED;

		if($result == HSF_CREATED){
			$message = array();
			$message['hsf_id'] = $reqW->{'HSFID'};
            $message['sync_flag'] = 1;
            $message['sync_time'] = date('Y-m-d H:i:s');
			array_push($a, $message);
		}
	
		if($result == HSF_EXISTS){
			$message = array();
			$message['hsf_id'] = $reqW->{'HSFID'};
            $message['sync_flag'] = 1;
            $message['sync_time'] = date('Y-m-d H:i:s');
			array_push($a, $message);
		}
	
		if($result == HSF_FAILURE){
			$message = array();
			$message['hsf_id'] = $reqW->{'HSFID'};
            $message['sync_flag'] = 0;
            $message['sync_time'] = date('Y-m-d H:i:s');
			array_push($a, $message);
		}
	
    }
    echo json_encode($a);

	// $response->getBody()->write(json_encode($a));
	// return $response;
	
}

function getMSA($request){
    //$request_body = $request->getParsedBody();
    //$req = json_decode($request_body['dateforMSA']);
    $req = $request->getAttribute('dateP');


    $db = new DbOperations;


    $result = $db->selectMSA($req);

    //echo $req,  "Tobi";
    
    echo json_encode($result);
}

function insertTransport($request){
    $request_body = $request->getParsedBody();
    $req = json_decode($request_body['transup']);

    $db = new DbOperations;
    $a = array();

    for($i = 0; $i < count($req); $i++){
        $reqW = $req[$i];

        $result = $db->insertTransport($reqW);
    
        date_default_timezone_set('Africa/Lagos');
		//$result = HSF_CREATED;

		if($result == TRANSPORT_CREATED){
			$message = array();
			$message['hsf_id'] = $reqW->{'HSFID'};
            $message['sync_flag'] = 1;
            $message['sync_time'] = date('Y-m-d H:i:s');
			array_push($a, $message);
		}
	
		if($result == TRANSPORT_EXIST){
			$message = array();
			$message['hsf_id'] = $reqW->{'HSFID'};
            $message['sync_flag'] = 1;
            $message['sync_time'] = date('Y-m-d H:i:s');
			array_push($a, $message);
		}
	
		if($result == TRANSPORT_FAILURE){
			$message = array();
			$message['hsf_id'] = $reqW->{'HSFID'};
            $message['sync_flag'] = 0;
            $message['sync_time'] = date('Y-m-d H:i:s');
			array_push($a, $message);
		}
	
    }
    echo json_encode($a);



}

